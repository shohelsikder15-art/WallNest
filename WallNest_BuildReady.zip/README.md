# WallNest — Build Ready

This is the WallNest starter Android app.

## Build an APK from a phone using GitHub Actions

1. Create/sign in to a GitHub account.
2. Create a new repository, for example `WallNest`.
3. Upload all files and folders from this project (including `.github/workflows/build-apk.yml`).
4. Open the repository's **Actions** tab.
5. Select **Build WallNest APK**.
6. Tap **Run workflow**.
7. When it finishes, open the workflow run and download the **WallNest-debug-apk** artifact.
8. Extract the downloaded ZIP and install `app-debug.apk` on your phone.

## Important

This is a UI starter. It includes Home, Search, Categories, wallpaper preview and demo online images.
The admin upload system, cloud database/storage, real download, favorites and direct wallpaper setting still need to be connected for the production version.

Only use wallpapers that you own or have permission to distribute.

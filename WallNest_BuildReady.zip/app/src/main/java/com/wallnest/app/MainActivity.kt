package com.wallnest.app

import android.app.WallpaperManager
import android.content.Context
import android.graphics.Bitmap
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage

data class Wallpaper(val title: String, val category: String, val url: String)

private val sampleWallpapers = listOf(
    Wallpaper("Mountain Night", "Nature", "https://images.unsplash.com/photo-1500534623283-312aade485b7?w=900"),
    Wallpaper("Forest Road", "Nature", "https://images.unsplash.com/photo-1448375240586-882707db888b?w=900"),
    Wallpaper("City Lights", "City", "https://images.unsplash.com/photo-1477959858617-67f85cf4f1df?w=900"),
    Wallpaper("Ocean", "Nature", "https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=900"),
    Wallpaper("Desert", "Nature", "https://images.unsplash.com/photo-1500530855697-b586d89ba3ee?w=900"),
    Wallpaper("Car", "Cars", "https://images.unsplash.com/photo-1503376780353-7e6692767b70?w=900")
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { WallNestApp() }
    }
}

@Composable
fun WallNestApp() {
    var selected by remember { mutableStateOf<Wallpaper?>(null) }
    var category by remember { mutableStateOf("All") }
    var query by remember { mutableStateOf("") }

    val categories = listOf("All", "Nature", "Cars", "City", "Anime", "Islamic", "Sports")
    val list = sampleWallpapers.filter {
        (category == "All" || it.category == category) &&
        it.title.contains(query, ignoreCase = true)
    }

    MaterialTheme(colorScheme = darkColorScheme(
        background = Color(0xFF0B0B10),
        surface = Color(0xFF15151D),
        primary = Color(0xFF9B8CFF)
    )) {
        Surface(Modifier.fillMaxSize()) {
            if (selected == null) {
                HomeScreen(categories, category, { category = it }, query, { query = it }, list) {
                    selected = it
                }
            } else {
                PreviewScreen(selected!!, onBack = { selected = null })
            }
        }
    }
}

@Composable
fun HomeScreen(
    categories: List<String>, category: String, onCategory: (String) -> Unit,
    query: String, onQuery: (String) -> Unit,
    wallpapers: List<Wallpaper>, onOpen: (Wallpaper) -> Unit
) {
    Column(Modifier.fillMaxSize().background(Color(0xFF0B0B10)).padding(16.dp)) {
        Text("WallNest", fontSize = 30.sp, fontWeight = FontWeight.Bold)
        Text("Beautiful wallpapers for your phone", color = Color.LightGray)
        Spacer(Modifier.height(14.dp))

        OutlinedTextField(
            value = query, onValueChange = onQuery,
            modifier = Modifier.fillMaxWidth(),
            placeholder = { Text("Search wallpapers") },
            singleLine = true
        )
        Spacer(Modifier.height(12.dp))

        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items(categories) { c ->
                FilterChip(selected = category == c, onClick = { onCategory(c) },
                    label = { Text(c) })
            }
        }
        Spacer(Modifier.height(14.dp))

        LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            contentPadding = PaddingValues(bottom = 20.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(wallpapers) { wallpaper ->
                Card(
                    modifier = Modifier.fillMaxWidth().height(260.dp).clickable { onOpen(wallpaper) },
                    shape = RoundedCornerShape(18.dp)
                ) {
                    AsyncImage(
                        model = wallpaper.url, contentDescription = wallpaper.title,
                        modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop
                    )
                }
            }
        }
    }
}

@Composable
fun PreviewScreen(wallpaper: Wallpaper, onBack: () -> Unit) {
    val context = LocalContext.current
    Column(Modifier.fillMaxSize().background(Color(0xFF0B0B10))) {
        Box(Modifier.fillMaxWidth().weight(1f)) {
            AsyncImage(
                model = wallpaper.url, contentDescription = wallpaper.title,
                modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop
            )
            TextButton(onClick = onBack, modifier = Modifier.padding(8.dp)) {
                Text("← Back", color = Color.White)
            }
        }
        Column(Modifier.padding(16.dp)) {
            Text(wallpaper.title, fontSize = 24.sp, fontWeight = FontWeight.Bold)
            Text(wallpaper.category, color = Color.Gray)
            Spacer(Modifier.height(12.dp))
            Button(
                onClick = {
                    // Full online-image saving and direct wallpaper setting
                    // will be connected after the backend is configured.
                    showInfo(context)
                },
                modifier = Modifier.fillMaxWidth()
            ) { Text("Download / Set Wallpaper") }
        }
    }
}

private fun showInfo(context: Context) {
    android.widget.Toast.makeText(
        context,
        "Backend connection is required for final download/set feature.",
        android.widget.Toast.LENGTH_LONG
    ).show()
}
